package net.mcreator.combat.procedure;

import net.minecraft.item.ItemStack;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.Entity;

import net.mcreator.combat.item.ItemIcon;
import net.mcreator.combat.ElementsCombat;

@ElementsCombat.ModElement.Tag
public class ProcedureIconItemInHandTick extends ElementsCombat.ModElement {
	public ProcedureIconItemInHandTick(ElementsCombat instance) {
		super(instance, 1);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure IconItemInHandTick!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		if (entity instanceof EntityPlayer)
			((EntityPlayer) entity).inventory.clearMatchingItems(new ItemStack(ItemIcon.block, (int) (1)).getItem(), -1, (int) 1, null);
	}
}

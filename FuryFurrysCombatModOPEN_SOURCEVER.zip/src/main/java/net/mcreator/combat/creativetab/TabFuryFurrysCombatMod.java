
package net.mcreator.combat.creativetab;

import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.relauncher.Side;

import net.minecraft.item.ItemStack;
import net.minecraft.creativetab.CreativeTabs;

import net.mcreator.combat.item.ItemIcon;
import net.mcreator.combat.ElementsCombat;

@ElementsCombat.ModElement.Tag
public class TabFuryFurrysCombatMod extends ElementsCombat.ModElement {
	public TabFuryFurrysCombatMod(ElementsCombat instance) {
		super(instance, 1);
	}

	@Override
	public void initElements() {
		tab = new CreativeTabs("tabfuryfurryscombatmod") {
			@SideOnly(Side.CLIENT)
			@Override
			public ItemStack getTabIconItem() {
				return new ItemStack(ItemIcon.block, (int) (1));
			}

			@SideOnly(Side.CLIENT)
			public boolean hasSearchBar() {
				return false;
			}
		};
	}
	public static CreativeTabs tab;
}
